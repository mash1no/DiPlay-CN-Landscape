package com.shilapi.xcertplay

import android.content.Intent
import android.net.wifi.WifiManager
import android.os.PowerManager
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.android.controller.ServiceController
import org.robolectric.util.ReflectionHelpers

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [25, 29], manifest = Config.NONE)
class SessionPowerLocksTest {
    private lateinit var service: DiPlaySessionService
    private lateinit var lifecycle: ServiceController<DiPlaySessionService>

    @Before fun setup() {
        CarPlayBackgroundSession.clear()
        lifecycle = Robolectric.buildService(DiPlaySessionService::class.java).create()
        service = lifecycle.get()
    }
    @After fun cleanup() { lifecycle.destroy(); CarPlayBackgroundSession.clear() }

    private fun ownsSession() {
        val stop: (() -> Unit) -> Unit = { complete -> CarPlayBackgroundSession.clear(); complete() }
        ReflectionHelpers.setField(CarPlayBackgroundSession, "stopAction", stop)
    }
    private fun start(wireless: Boolean = true) = service.onStartCommand(
        Intent(service, DiPlaySessionService::class.java).putExtra(DiPlaySessionService.EXTRA_WIRELESS, wireless), 0, 1)
    private fun held(): Pair<Boolean, Boolean> {
        val field = DiPlaySessionService::class.java.getDeclaredField("powerLocks\$delegate").apply { isAccessible = true }
        val power = (field.get(service) as Lazy<*>).value!!
        return ReflectionHelpers.getField<PowerManager.WakeLock>(power, "cpu").isHeld to
            ReflectionHelpers.getField<WifiManager.WifiLock>(power, "wifi").isHeld
    }

    @Test fun unownedServiceCannotHoldPowerOrCreateConnection() {
        start()
        assertEquals(false to false, held())
        assertFalse(CarPlayBackgroundSession.hasSession())
    }
    @Test fun repeatedStartsAndWiredSwitchDoNotLeakLocks() {
        ownsSession()
        start(); start()
        assertEquals(true to true, held())
        start(wireless = false)
        assertEquals(true to false, held())
        service.onStartCommand(Intent().setAction(DiPlaySessionService.ACTION_STOP), 0, 2)
        assertEquals(false to false, held())
        assertFalse(CarPlayBackgroundSession.hasSession())
    }
    @Test fun destructionReleasesBothResources() {
        ownsSession(); start()
        assertEquals(true to true, held())
        service.onDestroy()
        assertEquals(false to false, held())
    }
}
