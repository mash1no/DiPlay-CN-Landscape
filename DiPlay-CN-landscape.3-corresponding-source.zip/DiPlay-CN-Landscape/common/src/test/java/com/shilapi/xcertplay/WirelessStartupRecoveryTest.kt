package com.shilapi.xcertplay

import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import com.shilapi.xcertplay.network.WirelessStartupFailure
import com.shilapi.xcertplay.orchestration.CarPlayStatus
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import org.robolectric.util.ReflectionHelpers
import org.robolectric.util.ReflectionHelpers.ClassParameter.from
import java.util.concurrent.atomic.AtomicBoolean
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [29], qualifiers = "en", manifest = Config.NONE)
@LooperMode(LooperMode.Mode.PAUSED)
class WirelessStartupRecoveryTest {
    private lateinit var activity: CarPlayHostActivity
    private lateinit var retry: Button
    private val failure = CarPlayStatus.Failed("timeout", startupFailure = WirelessStartupFailure.FIRST_TCP_TIMEOUT)

    @Before fun setup() {
        CarPlayBackgroundSession.clear()
        DiPlayPreferences.saveConnectOnPhoneBluetooth(RuntimeEnvironment.getApplication(), false)
        activity = Robolectric.buildActivity(CarPlayHostActivity::class.java).get()
        activity.setTheme(android.R.style.Theme_Material_NoActionBar)
        ReflectionHelpers.setField(CarPlayBackgroundSession, "owner", activity)
        retry = Button(activity).apply { visibility = View.GONE }
        ReflectionHelpers.setField(activity, "startupRetryButton", retry)
    }

    @After fun cleanup() {
        ReflectionHelpers.getField<Handler>(activity, "mainHandler").removeCallbacksAndMessages(null)
        CarPlayBackgroundSession.clear()
    }

    private fun report(generation: Int = 0, status: CarPlayStatus = failure) {
        ReflectionHelpers.callInstanceMethod<(CarPlayStatus) -> Unit>(activity, "createStatusReporter",
            from(Int::class.javaPrimitiveType, generation))(status)
    }
    private fun budget() = ReflectionHelpers.getField<WirelessStartupRetryBudget>(activity, "startupRetryBudget")

    @Test fun duplicateFailureAndCleanupErrorScheduleOnlyOneRetry() {
        report()
        report()
        report(status = CarPlayStatus.Failed("Bluetooth socket closed"))
        assertEquals(1, budget().retries)
        assertEquals(1, ReflectionHelpers.getField<Int>(activity, "reconnectAttempts"))
    }

    @Test fun exhaustedBudgetStopsAutomaticRecoveryAndExposesRetry() {
        repeat(6) { generation ->
            ReflectionHelpers.setField(activity, "restartGeneration", generation)
            ReflectionHelpers.setField(activity, "reconnectScheduled", false)
            report(generation)
        }
        assertEquals(5, budget().retries)
        assertTrue(ReflectionHelpers.getField(activity, "startupRetryStopped"))
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
        assertEquals(View.VISIBLE, retry.visibility)
        report(5, CarPlayStatus.Failed("Bluetooth socket closed"))
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
    }

    @Test fun unrecoverableConfigurationDoesNotAutomaticallyRetry() {
        report(status = CarPlayStatus.Failed("Permission missing", startupFailure = WirelessStartupFailure.HOTSPOT_CONFIGURATION))
        assertEquals(0, budget().retries)
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
        assertEquals(View.VISIBLE, retry.visibility)
    }

    private fun allowOwnerWake() {
        val stop: (() -> Unit) -> Unit = { complete -> CarPlayBackgroundSession.clear(); complete() }
        val wake: () -> Unit = { activity.resumeLostSessionForPhone() }
        ReflectionHelpers.setField(CarPlayBackgroundSession, "stopAction", stop)
        ReflectionHelpers.setField(CarPlayBackgroundSession, "phoneWakeAction", wake)
    }

    @Test fun endedControlChannelSchedulesOneRetry() {
        report(status = CarPlayStatus.ControlEnded)
        report(status = CarPlayStatus.ControlEnded)
        assertTrue(ReflectionHelpers.getField(activity, "reconnectScheduled"))
        assertEquals(1, ReflectionHelpers.getField<Int>(activity, "reconnectAttempts"))
        assertFalse(CarPlayBackgroundSession.active)
    }

    @Test fun phoneReturnResumesExhaustedOwnerWithoutReplacingHealthySession() {
        allowOwnerWake()
        DiPlayPreferences.saveConnectOnPhoneBluetooth(activity, true)
        DiPlayPreferences.savePhone(activity, "12:34:56:78:9A:BC", "test phone")
        assertFalse(CarPlayBackgroundSession.resumeForPhone())
        repeat(6) { generation ->
            ReflectionHelpers.setField(activity, "restartGeneration", generation)
            ReflectionHelpers.setField(activity, "reconnectScheduled", false)
            report(generation)
        }
        assertTrue(ReflectionHelpers.getField(activity, "startupRetryStopped"))
        assertTrue(CarPlayBackgroundSession.resumeForPhone())
        assertFalse(ReflectionHelpers.getField(activity, "startupRetryStopped"))
        assertEquals(0, budget().retries)
        assertTrue(ReflectionHelpers.getField(activity, "reconnectScheduled"))
        assertEquals(1, ReflectionHelpers.getField<Int>(activity, "reconnectAttempts"))
        CarPlayBackgroundSession.stop()
        assertFalse(CarPlayBackgroundSession.resumeForPhone())
    }

    @Test fun cleanupErrorCannotMakeConfigurationFailureAutoRetryable() {
        allowOwnerWake()
        report(status = CarPlayStatus.Failed("Permission missing", startupFailure = WirelessStartupFailure.HOTSPOT_CONFIGURATION))
        report(status = CarPlayStatus.Failed("Bluetooth socket closed during cleanup"))
        assertFalse(CarPlayBackgroundSession.canResumeForPhone())
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
    }

    @Test fun cooldownRetriesOptedInPhoneButRejectsStaleGeneration() {
        allowOwnerWake()
        DiPlayPreferences.saveConnectOnPhoneBluetooth(activity, true)
        DiPlayPreferences.savePhone(activity, "12:34:56:78:9A:BC", "test phone")
        repeat(6) { generation ->
            ReflectionHelpers.setField(activity, "restartGeneration", generation)
            ReflectionHelpers.setField(activity, "reconnectScheduled", false)
            report(generation)
        }
        // A newer connection owns recovery before the previous burst's cooldown expires.
        ReflectionHelpers.setField(activity, "restartGeneration", 6)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(90))
        assertTrue(ReflectionHelpers.getField(activity, "startupRetryStopped"))
        assertFalse(ReflectionHelpers.getField(activity, "reconnectScheduled"))
    }

    @Test fun cooldownResumesWhenPhoneWakeBroadcastIsMissing() {
        allowOwnerWake()
        DiPlayPreferences.saveConnectOnPhoneBluetooth(activity, true)
        DiPlayPreferences.savePhone(activity, "12:34:56:78:9A:BC", "test phone")
        repeat(6) { generation ->
            ReflectionHelpers.setField(activity, "restartGeneration", generation)
            ReflectionHelpers.setField(activity, "reconnectScheduled", false)
            report(generation)
        }
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(90))
        assertFalse(ReflectionHelpers.getField(activity, "startupRetryStopped"))
        assertEquals(0, budget().retries)
        assertTrue(ReflectionHelpers.getField(activity, "reconnectScheduled"))
    }

    @Test fun staleGenerationUserDisconnectMenuAndDifferentOwnerCannotSchedule() {
        report(1)
        assertEquals(0, budget().retries)
        ReflectionHelpers.setField(activity, "menuOpen", true)
        report()
        assertEquals(0, budget().retries)
        ReflectionHelpers.setField(activity, "menuOpen", false)
        ReflectionHelpers.getField<AtomicBoolean>(activity, "shuttingDown").set(true)
        report()
        assertEquals(0, budget().retries)
        ReflectionHelpers.getField<AtomicBoolean>(activity, "shuttingDown").set(false)
        ReflectionHelpers.setField(CarPlayBackgroundSession, "owner", Any())
        report()
        assertEquals(0, budget().retries)
    }
}
