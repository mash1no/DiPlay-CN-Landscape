package com.shilapi.xcertplay

import android.annotation.SuppressLint
import android.content.Context
import android.net.wifi.WifiManager
import android.os.PowerManager
import android.util.Log

/** Owned by the explicit connection's foreground service, including background recovery. */
internal class SessionPowerLocks(context: Context) {
    private val cpu = (context.getSystemService(Context.POWER_SERVICE) as PowerManager)
        .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DiPlay:CarPlaySession").apply { setReferenceCounted(false) }
    @Suppress("DEPRECATION")
    private val wifi = (context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
        .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "DiPlay:CarPlayWireless").apply { setReferenceCounted(false) }

    // The foreground service releases on Disconnect, task removal and destruction. A fixed
    // timeout would silently drop an ongoing journey; these locks never create a new session.
    @SuppressLint("WakelockTimeout")
    fun acquire(wireless: Boolean) {
        try {
            if (!cpu.isHeld) cpu.acquire()
            if (wireless) {
                if (!wifi.isHeld) wifi.acquire()
            } else if (wifi.isHeld) wifi.release()
        } catch (error: RuntimeException) {
            Log.w("DiPlaySessionPower", "Session power lock unavailable: ${error.javaClass.simpleName}")
        }
    }

    fun release() {
        runCatching { if (wifi.isHeld) wifi.release() }
            .onFailure { Log.w("DiPlaySessionPower", "Wi-Fi lock release failed: ${it.javaClass.simpleName}") }
        runCatching { if (cpu.isHeld) cpu.release() }
            .onFailure { Log.w("DiPlaySessionPower", "CPU lock release failed: ${it.javaClass.simpleName}") }
    }
}
