# DiPlay next release notes

Changes through DiPlay 0.2.17 are documented in [0.2.17 release notes](RELEASE-NOTES-0.2.17.md). Measured checks are in [VALIDATION.md](VALIDATION.md). Device acceptance and remaining failure families are tracked in [connection reliability validation](CONNECTION_RELIABILITY.md).

No unreleased changes are recorded yet. Add future unreleased changes here.
